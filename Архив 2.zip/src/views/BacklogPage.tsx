import * as React from "react";
import {
  Paper,
  Typography,
  Stack,
  Box,
  Chip,
  Select,
  MenuItem,
  IconButton,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Autocomplete,
  Tooltip,
} from "@mui/material";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";
import CloseIcon from "@mui/icons-material/Close";

import {
  useGetQuartersQuery,
  useGetParticipantsQuery,
  useGetSprintsQuery,
  useGetTasksQuery,
  useUpdateTaskMutation,
  useUpsertTaskAllocationMutation,
  useDuplicateTaskMutation,
} from "../app/api";
import type { BacklogItem, Participant, Sprint, TaskPriority } from "../types";
import { useDispatch, useSelector } from "react-redux";
import type { RootState } from "../app/store";
import { setBacklogFilters } from "../app/uiSlice";

const byStart = (a: Sprint, b: Sprint) =>
  a.startDate.localeCompare(b.startDate);
const toInt = (n: any) =>
  Number.isFinite(Number(n)) ? Math.round(Number(n)) : 0;

function ClickToEdit({
  value,
  onSave,
  type = "text",
  placeholder,
  options,
}: {
  value: string;
  onSave: (v: string) => void;
  type?: "text" | "multiline" | "select";
  placeholder?: string;
  options?: string[];
}) {
  const [editing, setEditing] = React.useState(false);
  const [draft, setDraft] = React.useState(value ?? "");

  React.useEffect(() => {
    setDraft(value ?? "");
  }, [value]);

  const commit = () => {
    setEditing(false);
    if (draft !== value) onSave(draft ?? "");
  };

  if (!editing) {
    return (
      <Box
        onClick={() => setEditing(true)}
        sx={{ cursor: "text", minHeight: 24 }}
      >
        <Typography sx={{ whiteSpace: "pre-wrap" }}>
          {value?.trim() ? (
            value
          ) : (
            <Typography component="span" sx={{ color: "text.disabled" }}>
              {placeholder || "—"}
            </Typography>
          )}
        </Typography>
      </Box>
    );
  }

  if (type === "multiline") {
    return (
      <Stack direction="row" spacing={1} alignItems="flex-start">
        <TextField
          autoFocus
          fullWidth
          size="small"
          multiline
          minRows={2}
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Escape") {
              setEditing(false);
              setDraft(value ?? "");
            }
          }}
        />
        <IconButton color="primary" onClick={commit}>
          <SaveIcon fontSize="small" />
        </IconButton>
        <IconButton
          onClick={() => {
            setEditing(false);
            setDraft(value ?? "");
          }}
        >
          <CloseIcon fontSize="small" />
        </IconButton>
      </Stack>
    );
  }

  if (type === "select" && options?.length) {
    return (
      <Stack direction="row" spacing={1} alignItems="center">
        <Select
          autoFocus
          size="small"
          value={draft || ""}
          onChange={(e) => setDraft(String(e.target.value))}
          onKeyDown={(e) => {
            if (e.key === "Escape") {
              setEditing(false);
              setDraft(value ?? "");
            }
          }}
          sx={{ minWidth: 160 }}
        >
          {options.map((o) => (
            <MenuItem key={o} value={o}>
              {o}
            </MenuItem>
          ))}
        </Select>
        <IconButton color="primary" onClick={commit}>
          <SaveIcon fontSize="small" />
        </IconButton>
        <IconButton
          onClick={() => {
            setEditing(false);
            setDraft(value ?? "");
          }}
        >
          <CloseIcon fontSize="small" />
        </IconButton>
      </Stack>
    );
  }

  return (
    <Stack direction="row" spacing={1} alignItems="center">
      <TextField
        autoFocus
        fullWidth
        size="small"
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") commit();
          if (e.key === "Escape") {
            setEditing(false);
            setDraft(value ?? "");
          }
        }}
      />
      <IconButton color="primary" onClick={commit}>
        <SaveIcon fontSize="small" />
      </IconButton>
      <IconButton
        onClick={() => {
          setEditing(false);
          setDraft(value ?? "");
        }}
      >
        <CloseIcon fontSize="small" />
      </IconButton>
    </Stack>
  );
}

export default function BacklogPage() {
  const dispatch = useDispatch();
  const ui = useSelector((s: RootState) => s.ui.backlog);

  const { data: quarters = [] } = useGetQuartersQuery();
  const { data: participants = [] } = useGetParticipantsQuery();
  const allSprints = useGetSprintsQuery(undefined).data ?? [];

  const sprintsInQuarter = React.useMemo(() => {
    if (ui.quarterId === "all") return [...allSprints].sort(byStart);
    return allSprints.filter((s) => s.quarterId === ui.quarterId).sort(byStart);
  }, [allSprints, ui.quarterId]);

  const { data: tasks = [] } = useGetTasksQuery(
    ui.quarterId === "all" ? undefined : { quarterId: ui.quarterId }
  );

  const [updateTask] = useUpdateTaskMutation();
  const [upsertAllocation] = useUpsertTaskAllocationMutation();
  const [duplicateTask] = useDuplicateTaskMutation();

  const streamOptions = React.useMemo(
    () =>
      Array.from(new Set(tasks.map((t) => t.stream).filter(Boolean))).sort(),
    [tasks]
  );
  const customerOptions = React.useMemo(
    () =>
      Array.from(new Set(tasks.map((t) => t.customer).filter(Boolean))).sort(),
    [tasks]
  );

  const filteredTasks = React.useMemo(() => {
    let list = tasks.slice();
    if (ui.priorityFilter?.length) {
      const set = new Set(ui.priorityFilter);
      list = list.filter((t) => set.has(t.priority));
    }
    if (ui.releaseSprintFilter && ui.releaseSprintFilter !== "all") {
      list = list.filter((t) => t.releaseSprintId === ui.releaseSprintFilter);
    }
    return list;
  }, [tasks, ui.priorityFilter, ui.releaseSprintFilter]);

  const sprintIds = sprintsInQuarter.map((s) => s.id);

  const perTaskRows = (t: BacklogItem) => {
    const ids = t.participantIds.length ? t.participantIds : ["" as any];
    return ids.map((pid) => ({
      pid,
      participant: participants.find((p) => p.id === pid) || null,
      perSprint: sprintIds.map((sid) =>
        toInt(t.allocations?.[pid]?.[sid] ?? 0)
      ),
      note: t.notes?.[pid] ?? "",
    }));
  };

  const changeTaskField = async (
    t: BacklogItem,
    patch: Partial<BacklogItem>
  ) => {
    await updateTask({ id: t.id, ...patch }).unwrap();
  };

  const changeAllocation = async (
    task: BacklogItem,
    pid: string,
    sid: string,
    days: number
  ) => {
    if (!pid) return;
    await upsertAllocation({
      taskId: task.id,
      participantId: pid,
      sprintId: sid,
      days: Math.max(0, toInt(days)),
    }).unwrap();
  };

  const handleDuplicate = async (id: string) => {
    await duplicateTask({ id }).unwrap();
  };

  const quarterSelect = (
    <Box sx={{ minWidth: 260 }}>
      <Typography variant="caption" color="text.secondary">
        Квартал
      </Typography>
      <Select
        size="small"
        value={ui.quarterId}
        onChange={(e) =>
          dispatch(setBacklogFilters({ quarterId: String(e.target.value) }))
        }
        sx={{ ml: 1, minWidth: 220 }}
      >
        <MenuItem value="all">Все кварталы</MenuItem>
        {quarters.map((q) => (
          <MenuItem key={q.id} value={q.id}>
            {q.name} ({q.startDate} → {q.endDate})
          </MenuItem>
        ))}
      </Select>
    </Box>
  );

  const releaseSelect = (
    <Box sx={{ minWidth: 260 }}>
      <Typography variant="caption" color="text.secondary">
        Релиз (спринт)
      </Typography>
      <Select
        size="small"
        value={ui.releaseSprintFilter}
        onChange={(e) =>
          dispatch(
            setBacklogFilters({ releaseSprintFilter: String(e.target.value) })
          )
        }
        sx={{ ml: 1, minWidth: 220 }}
      >
        <MenuItem value="all">Все релизы</MenuItem>
        {sprintsInQuarter.map((s) => (
          <MenuItem key={s.id} value={s.id}>
            {s.name}: {s.startDate} → {s.endDate}
          </MenuItem>
        ))}
      </Select>
    </Box>
  );

  const prioritySelect = (
    <Box sx={{ minWidth: 180 }}>
      <Typography variant="caption" color="text.secondary">
        Приоритет
      </Typography>
      <Select
        multiple
        size="small"
        value={ui.priorityFilter}
        onChange={(e) =>
          dispatch(
            setBacklogFilters({
              priorityFilter: (e.target.value as number[]).length
                ? (e.target.value as number[])
                : [1, 2, 3],
            })
          )
        }
        renderValue={(vals) => (vals as number[]).join(", ")}
        sx={{ ml: 1, minWidth: 140 }}
      >
        {[1, 2, 3].map((p) => (
          <MenuItem key={p} value={p}>
            {p}
          </MenuItem>
        ))}
      </Select>
    </Box>
  );

  return (
    <Paper elevation={0} sx={{ p: 2 }}>
      <Typography variant="h6" sx={{ mb: 2 }}>
        Бэклог
      </Typography>

      <Stack
        direction={{ xs: "column", md: "row" }}
        spacing={2}
        alignItems="center"
        sx={{ mb: 2, flexWrap: "wrap" }}
      >
        {quarterSelect}
        {releaseSelect}
        {prioritySelect}
      </Stack>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ minWidth: 260 }}>Задача</TableCell>
              <TableCell sx={{ minWidth: 240 }}>DoD</TableCell>
              <TableCell align="center" sx={{ width: 100 }}>
                Приор.
              </TableCell>
              <TableCell sx={{ minWidth: 160 }}>Заказчик</TableCell>
              <TableCell sx={{ minWidth: 180 }}>Стрим</TableCell>
              <TableCell sx={{ minWidth: 260 }}>Участники</TableCell>
              <TableCell sx={{ minWidth: 240 }}>Релиз</TableCell>
              {sprintsInQuarter.map((s) => (
                <TableCell key={s.id} align="center">
                  <Typography variant="caption" sx={{ fontWeight: 700 }}>
                    {s.name}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {s.startDate} → {s.endDate}
                  </Typography>
                </TableCell>
              ))}
              <TableCell sx={{ minWidth: 220 }}>
                Заметка (по участнику)
              </TableCell>
              <TableCell align="center" width={48} />
            </TableRow>
          </TableHead>

          <TableBody>
            {filteredTasks.map((t) => {
              const rows = perTaskRows(t);
              const rowSpan = Math.max(1, rows.length);

              return rows.map((r, idx) => {
                const first = idx === 0;

                return (
                  <TableRow key={`${t.id}-${r.pid || "none"}`} hover>
                    {first && (
                      <TableCell rowSpan={rowSpan}>
                        <Stack direction="row" spacing={1} alignItems="center">
                          <Chip
                            size="small"
                            label={`P${t.priority}`}
                            color={
                              t.priority === 1
                                ? "error"
                                : t.priority === 2
                                ? "warning"
                                : "default"
                            }
                          />
                          <ClickToEdit
                            value={t.title}
                            onSave={(v) => changeTaskField(t, { title: v })}
                            placeholder="Название задачи"
                          />
                        </Stack>
                      </TableCell>
                    )}

                    {first && (
                      <TableCell rowSpan={rowSpan}>
                        <ClickToEdit
                          value={t.dod || ""}
                          onSave={(v) => changeTaskField(t, { dod: v })}
                          type="multiline"
                          placeholder="Definition of Done"
                        />
                      </TableCell>
                    )}

                    {first && (
                      <TableCell rowSpan={rowSpan} align="center">
                        <Select
                          size="small"
                          value={t.priority as TaskPriority}
                          onChange={(e) =>
                            changeTaskField(t, {
                              priority: Number(e.target.value) as TaskPriority,
                            })
                          }
                          sx={{ minWidth: 80 }}
                        >
                          {[1, 2, 3].map((p) => (
                            <MenuItem key={p} value={p}>
                              {p}
                            </MenuItem>
                          ))}
                        </Select>
                      </TableCell>
                    )}

                    {first && (
                      <TableCell rowSpan={rowSpan}>
                        <ClickToEdit
                          value={t.customer || ""}
                          onSave={(v) => changeTaskField(t, { customer: v })}
                          placeholder="Заказчик"
                        />
                      </TableCell>
                    )}

                    {first && (
                      <TableCell rowSpan={rowSpan}>
                        <ClickToEdit
                          value={t.stream || ""}
                          onSave={(v) => changeTaskField(t, { stream: v })}
                          type="select"
                          options={[...streamOptions, ""].filter(
                            (v, i, arr) => arr.indexOf(v) === i
                          )}
                          placeholder="Стрим"
                        />
                      </TableCell>
                    )}

                    {first && (
                      <TableCell rowSpan={rowSpan}>
                        <Autocomplete
                          multiple
                          size="small"
                          options={participants}
                          getOptionLabel={(p) =>
                            p ? `${p.fullName} (${p.role})` : ""
                          }
                          value={participants.filter((p) =>
                            t.participantIds.includes(p.id)
                          )}
                          onChange={(_, val) =>
                            changeTaskField(t, {
                              participantIds: (val as Participant[]).map(
                                (x) => x.id
                              ),
                            })
                          }
                          renderInput={(params) => (
                            <TextField {...params} label="Команда" />
                          )}
                          sx={{ minWidth: 240 }}
                        />
                      </TableCell>
                    )}

                    {first && (
                      <TableCell rowSpan={rowSpan}>
                        <Stack direction="row" spacing={1} alignItems="center">
                          <TextField
                            size="small"
                            type="date"
                            label="Дата релиза"
                            value={t.releaseDate || ""}
                            InputLabelProps={{ shrink: true }}
                            onChange={(e) =>
                              changeTaskField(t, {
                                releaseDate: e.target.value,
                              })
                            }
                            sx={{ minWidth: 160 }}
                          />
                          <Select
                            size="small"
                            value={t.releaseSprintId || ""}
                            onChange={(e) =>
                              changeTaskField(t, {
                                releaseSprintId: String(e.target.value),
                              })
                            }
                            displayEmpty
                            sx={{ minWidth: 160 }}
                          >
                            <MenuItem value="">
                              <em>Без спринта</em>
                            </MenuItem>
                            {sprintsInQuarter.map((s) => (
                              <MenuItem key={s.id} value={s.id}>
                                {s.name}
                              </MenuItem>
                            ))}
                          </Select>
                        </Stack>
                      </TableCell>
                    )}

                    {sprintIds.map((sid, i) => {
                      const v = r.perSprint[i] ?? 0;
                      return (
                        <TableCell key={sid} align="center">
                          {!!r.participant ? (
                            <TextField
                              size="small"
                              type="number"
                              value={String(v)}
                              onFocus={(e) => e.currentTarget.select()}
                              onChange={(e) =>
                                changeAllocation(
                                  t,
                                  r.participant!.id,
                                  sid,
                                  toInt(e.target.value)
                                )
                              }
                              inputProps={{ min: 0, step: 1 }}
                              sx={{ maxWidth: 80 }}
                            />
                          ) : (
                            <Typography sx={{ color: "text.disabled" }}>
                              —
                            </Typography>
                          )}
                        </TableCell>
                      );
                    })}

                    <TableCell>
                      {!!r.participant ? (
                        <ClickToEdit
                          value={t.notes?.[r.participant.id] || ""}
                          onSave={(v) =>
                            changeTaskField(t, {
                              notes: {
                                ...(t.notes || {}),
                                [r.participant!.id]: v,
                              },
                            })
                          }
                          placeholder="Заметка"
                        />
                      ) : (
                        <Typography sx={{ color: "text.disabled" }}>
                          Добавьте участника, чтобы оставить заметку
                        </Typography>
                      )}
                    </TableCell>

                    {first && (
                      <TableCell rowSpan={rowSpan} align="center">
                        <Tooltip title="Дублировать задачу">
                          <IconButton onClick={() => handleDuplicate(t.id)}>
                            <ContentCopyIcon fontSize="small" />
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                    )}
                  </TableRow>
                );
              });
            })}

            {!filteredTasks.length && (
              <TableRow>
                <TableCell colSpan={9 + sprintsInQuarter.length}>
                  <Box
                    sx={{ py: 2, textAlign: "center", color: "text.secondary" }}
                  >
                    Задач не найдено под текущие фильтры
                  </Box>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
    </Paper>
  );
}
