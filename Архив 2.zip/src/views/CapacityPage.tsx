import * as React from "react";
import {
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Chip,
  Stack,
  Box,
  Select,
  MenuItem,
} from "@mui/material";

import {
  useGetQuartersQuery,
  useGetSprintsQuery,
  useGetCapacityQuery,
  useGetParticipantsQuery,
} from "../app/api";
import { useDispatch, useSelector } from "react-redux";
import type { RootState } from "../app/store";
import { setCapacityQuarter } from "../app/uiSlice";

export default function CapacityPage() {
  const dispatch = useDispatch();
  const { data: quarters = [] } = useGetQuartersQuery();
  const quarterId = useSelector((s: RootState) => s.ui.capacity.quarterId);

  React.useEffect(() => {
    if (!quarterId && quarters.length) {
      dispatch(setCapacityQuarter(quarters[0].id));
    }
  }, [quarters, quarterId, dispatch]);

  const sprints =
    useGetSprintsQuery(quarterId ? { quarterId } : undefined).data ?? [];
  const { data: rows = [] } = useGetCapacityQuery(
    quarterId ? { quarterId } : (undefined as any)
  );
  const { data: participants = [] } = useGetParticipantsQuery();

  const sprintOrder = React.useMemo(
    () => sprints.slice().sort((a, b) => a.order - b.order),
    [sprints]
  );

  return (
    <Paper elevation={0} sx={{ p: 2 }}>
      <Stack
        direction="row"
        spacing={2}
        alignItems="center"
        justifyContent="space-between"
        sx={{ mb: 2, flexWrap: "wrap" }}
      >
        <Typography variant="h6">Емкость по спринтам</Typography>
        <Box sx={{ minWidth: 260 }}>
          <Typography variant="caption" color="text.secondary">
            Квартал
          </Typography>
          <Select
            size="small"
            value={quarterId ?? ""}
            onChange={(e) =>
              dispatch(setCapacityQuarter(String(e.target.value)))
            }
            sx={{ ml: 1, minWidth: 220 }}
          >
            {quarters.map((q) => (
              <MenuItem key={q.id} value={q.id}>
                {q.name} ({q.startDate} → {q.endDate})
              </MenuItem>
            ))}
          </Select>
        </Box>
      </Stack>

      <TableContainer component={Paper} variant="outlined">
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell sx={{ minWidth: 260 }}>Участник</TableCell>
              {sprintOrder.map((s) => (
                <TableCell key={s.id} align="center">
                  <Stack spacing={0} alignItems="center">
                    <Typography variant="caption" sx={{ fontWeight: 700 }}>
                      {s.startDate} → {s.endDate}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {s.name}
                    </Typography>
                  </Stack>
                </TableCell>
              ))}
              <TableCell align="center">Итого доступно</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {rows.map((r) => {
              const p = participants.find((x) => x.id === r.participant.id);
              return (
                <TableRow key={r.participant.id} hover>
                  <TableCell>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Chip size="small" label={r.participant.role} />
                      <Typography>{r.participant.fullName}</Typography>
                    </Stack>
                  </TableCell>

                  {sprintOrder.map((s) => {
                    const cell = r.cells.find((c) => c.sprintId === s.id);
                    if (!cell) return <TableCell key={s.id} />;
                    const taskLoad =
                      cell.baseCapacity -
                      cell.availableDays -
                      (cell.runDays || 0) -
                      (cell.vacationNormDays || 0);
                    const base = cell.baseCapacity;
                    const deviation =
                      base > 0 ? Math.abs(taskLoad - base) / base : 0;
                    const over = deviation > 0.25;

                    return (
                      <TableCell
                        key={s.id}
                        align="center"
                        sx={{
                          bgcolor: over ? "rgba(255, 0, 0, 0.08)" : undefined,
                          fontWeight: over ? 700 : 500,
                        }}
                        title={`Нагрузка / Доступно`}
                      >
                        {Math.round(taskLoad)} / {base}
                      </TableCell>
                    );
                  })}

                  <TableCell align="center" sx={{ fontWeight: 700 }}>
                    {Math.round(r.totalQuarterAvailable)}
                  </TableCell>
                </TableRow>
              );
            })}
            {!rows.length && (
              <TableRow>
                <TableCell colSpan={1 + sprintOrder.length + 1}>
                  <Box
                    sx={{
                      py: 2,
                      textAlign: "center",
                      color: "text.secondary",
                    }}
                  >
                    Нет данных
                  </Box>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>

      <Typography
        variant="caption"
        color="text.secondary"
        sx={{ mt: 2, display: "block" }}
      >
        В расчёте используется норм-фактор 0.75. Поля run/отпуск скрыты —
        нагрузка берётся из задач бэклога. Ячейки подсвечиваются при отклонении
        нагрузки более чем на 25% от доступного (нормированного) времени.
      </Typography>
    </Paper>
  );
}
