import {
  createApi,
  fetchBaseQuery,
  BaseQueryFn,
} from "@reduxjs/toolkit/query/react";
import type {
  Quarter,
  Sprint,
  Participant,
  RunVacation,
  CapacityRow,
  BacklogItem,
  TaskPriority,
} from "../types";
import { mockBaseQuery } from "../mock/mockApi";
import type { RootState } from "./store";
import { pushUndo } from "./undoSlice";

const USE_MOCK = process.env.USE_MOCK === "true";

const baseQuery = USE_MOCK
  ? (mockBaseQuery as BaseQueryFn)
  : fetchBaseQuery({ baseUrl: process.env.API_URL || "/api" });

export const api = createApi({
  reducerPath: "api",
  baseQuery,
  tagTypes: [
    "Quarter",
    "Sprint",
    "Participant",
    "RunVacation",
    "Capacity",
    "Task",
  ],
  endpoints: (b) => ({
    // ---- Quarters ----
    getQuarters: b.query<Quarter[], void>({
      query: () => ({ url: "/quarters", method: "GET" }),
      providesTags: ["Quarter"],
    }),
    addQuarter: b.mutation<Quarter, Partial<Quarter>>({
      query: (body) => ({ url: "/quarters", method: "POST", body }),
      invalidatesTags: ["Quarter"],
      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(pushUndo({ kind: "quarters/delete", id: data.id }));
        } catch {}
      },
    }),
    updateQuarter: b.mutation<Quarter, Partial<Quarter> & { id: string }>({
      query: (body) => ({ url: "/quarters/update", method: "POST", body }),
      invalidatesTags: ["Quarter", "Sprint", "Task"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const prev = (
          api.endpoints.getQuarters.select()(getState() as RootState).data || []
        ).find((q) => q.id === arg.id);
        try {
          await queryFulfilled;
          if (prev)
            dispatch(pushUndo({ kind: "quarters/update", quarter: prev }));
        } catch {}
      },
    }),
    deleteQuarter: b.mutation<Quarter, { id: string }>({
      query: (body) => ({ url: "/quarters/delete", method: "POST", body }),
      invalidatesTags: ["Quarter", "Sprint", "Task", "Capacity", "RunVacation"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const prev = (
          api.endpoints.getQuarters.select()(getState() as RootState).data || []
        ).find((q) => q.id === arg.id);
        try {
          await queryFulfilled;
          if (prev) dispatch(pushUndo({ kind: "quarters/add", quarter: prev }));
        } catch {}
      },
    }),

    // ---- Sprints ----
    getSprints: b.query<Sprint[], { quarterId?: string } | void>({
      query: (arg) =>
        arg?.quarterId
          ? ({
              url: `/sprints`,
              method: "GET",
              params: { quarterId: arg.quarterId },
            } as any)
          : { url: "/sprints", method: "GET" },
      providesTags: ["Sprint", "Quarter"],
    }),
    addSprint: b.mutation<Sprint, Partial<Sprint>>({
      query: (body) => ({ url: "/sprints", method: "POST", body }),
      invalidatesTags: ["Sprint", "Quarter", "Task", "Capacity", "RunVacation"],
      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(pushUndo({ kind: "sprints/delete", id: data.id }));
        } catch {}
      },
    }),
    updateSprint: b.mutation<Sprint, Partial<Sprint> & { id: string }>({
      query: (body) => ({ url: "/sprints/update", method: "POST", body }),
      invalidatesTags: ["Sprint", "Capacity", "RunVacation", "Task"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const prev = (
          api.endpoints.getSprints.select(undefined)(getState() as RootState)
            .data || []
        ).find((s) => s.id === arg.id);
        try {
          await queryFulfilled;
          if (prev)
            dispatch(pushUndo({ kind: "sprints/update", sprint: prev }));
        } catch {}
      },
    }),
    deleteSprint: b.mutation<Sprint, { id: string }>({
      query: (body) => ({ url: "/sprints/delete", method: "POST", body }),
      invalidatesTags: ["Sprint", "Capacity", "RunVacation", "Task"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const prev = (
          api.endpoints.getSprints.select(undefined)(getState() as RootState)
            .data || []
        ).find((s) => s.id === arg.id);
        try {
          await queryFulfilled;
          if (prev) dispatch(pushUndo({ kind: "sprints/add", sprint: prev }));
        } catch {}
      },
    }),

    // ---- Participants ----
    getParticipants: b.query<Participant[], void>({
      query: () => ({ url: "/participants", method: "GET" }),
      providesTags: ["Participant"],
    }),
    addParticipant: b.mutation<Participant, Partial<Participant>>({
      query: (body) => ({ url: "/participants", method: "POST", body }),
      invalidatesTags: ["Participant", "Capacity", "RunVacation"],
      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(pushUndo({ kind: "participants/delete", id: data.id }));
        } catch {}
      },
    }),
    updateParticipant: b.mutation<
      Participant,
      Partial<Participant> & { id: string }
    >({
      query: (body) => ({ url: "/participants/update", method: "POST", body }),
      invalidatesTags: ["Participant", "Capacity", "RunVacation"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const prev = (
          api.endpoints.getParticipants.select()(getState() as RootState)
            .data || []
        ).find((p) => p.id === arg.id);
        try {
          await queryFulfilled;
          if (prev)
            dispatch(
              pushUndo({ kind: "participants/update", participant: prev })
            );
        } catch {}
      },
    }),
    deleteParticipant: b.mutation<Participant, { id: string }>({
      query: (body) => ({ url: "/participants/delete", method: "POST", body }),
      invalidatesTags: ["Participant", "Capacity", "RunVacation", "Task"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const prev = (
          api.endpoints.getParticipants.select()(getState() as RootState)
            .data || []
        ).find((p) => p.id === arg.id);
        try {
          await queryFulfilled;
          if (prev)
            dispatch(pushUndo({ kind: "participants/add", participant: prev }));
        } catch {}
      },
    }),
    reorderParticipants: b.mutation<
      { ok: true },
      { orders: { id: string; order: number }[] }
    >({
      query: (body) => ({ url: "/participants/reorder", method: "POST", body }),
      invalidatesTags: ["Participant"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const current =
          api.endpoints.getParticipants.select()(getState() as RootState)
            .data || [];
        const prevOrders = current.map((p, idx) => ({ id: p.id, order: idx }));
        try {
          await queryFulfilled;
          dispatch(
            pushUndo({ kind: "participants/reorder", orders: prevOrders })
          );
        } catch {}
      },
    }),

    // ---- Run/Vacation & Capacity ----
    getRunVacation: b.query<RunVacation[], { quarterId: string }>({
      query: ({ quarterId }) =>
        ({ url: "/runvac", method: "GET", params: { quarterId } } as any),
      providesTags: ["RunVacation"],
    }),
    upsertRunVacation: b.mutation<RunVacation, Partial<RunVacation>>({
      query: (body) => ({ url: "/runvac", method: "POST", body }),
      invalidatesTags: ["RunVacation", "Capacity"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const list =
          api.endpoints.getRunVacation.select({
            quarterId: (getState() as RootState).ui.capacity.quarterId!,
          })(getState() as RootState).data || [];
        const prev = list.find(
          (x) =>
            x.participantId === arg.participantId && x.sprintId === arg.sprintId
        );
        try {
          await queryFulfilled;
          if (prev) dispatch(pushUndo({ kind: "runvac/set", rv: prev }));
        } catch {}
      },
    }),
    bulkRunVacation: b.mutation<
      { ok: true },
      {
        quarterId: string;
        roles?: string[];
        daysPerSprint: number;
        multiplyByRate: boolean;
      }
    >({
      query: (body) => ({ url: "/runvac/bulk", method: "POST", body }),
      invalidatesTags: ["RunVacation", "Capacity"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        // снимем срез до изменения, чтобы восстановить
        const prev =
          api.endpoints.getRunVacation.select({ quarterId: arg.quarterId })(
            getState() as RootState
          ).data || [];
        try {
          await queryFulfilled;
          dispatch(pushUndo({ kind: "runvac/bulk-restore", items: prev }));
        } catch {}
      },
    }),
    getCapacity: b.query<CapacityRow[], { quarterId: string }>({
      query: ({ quarterId }) =>
        ({ url: "/capacity", method: "GET", params: { quarterId } } as any),
      providesTags: ["Capacity", "Sprint", "Participant", "RunVacation"],
    }),

    // ---- Backlog ----
    getTasks: b.query<BacklogItem[], { quarterId?: string } | void>({
      query: (arg) =>
        arg?.quarterId
          ? ({
              url: "/tasks",
              method: "GET",
              params: { quarterId: arg.quarterId },
            } as any)
          : { url: "/tasks", method: "GET" },
      providesTags: ["Task", "Sprint"],
    }),
    addTask: b.mutation<BacklogItem, Partial<BacklogItem>>({
      query: (body) => ({ url: "/tasks", method: "POST", body }),
      invalidatesTags: ["Task"],
      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(pushUndo({ kind: "tasks/delete", id: data.id }));
        } catch {}
      },
    }),
    updateTask: b.mutation<BacklogItem, Partial<BacklogItem> & { id: string }>({
      query: (body) => ({ url: "/tasks/update", method: "POST", body }),
      invalidatesTags: ["Task", "Capacity"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        // попробуем найти задачу в любом кэше
        const state = getState() as RootState;
        const tryCaches = [
          api.endpoints.getTasks.select(undefined)(state)?.data,
          ...Object.values((state as any).api.queries)
            .filter(
              (q: any) =>
                q?.endpointName === "getTasks" && q?.status === "fulfilled"
            )
            .map((q: any) => q?.data),
        ];
        let prev: BacklogItem | undefined;
        for (const arr of tryCaches) {
          if (Array.isArray(arr)) {
            prev = arr.find((t) => t.id === arg.id);
            if (prev) break;
          }
        }
        try {
          await queryFulfilled;
          if (prev) dispatch(pushUndo({ kind: "tasks/update", task: prev }));
        } catch {}
      },
    }),
    deleteTask: b.mutation<BacklogItem, { id: string }>({
      query: (body) => ({ url: "/tasks/delete", method: "POST", body }),
      invalidatesTags: ["Task", "Capacity"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        // найдём полный объект задачи, чтобы можно было восстановить
        const state = getState() as RootState;
        const tryCaches = [
          api.endpoints.getTasks.select(undefined)(state)?.data,
          ...Object.values((state as any).api.queries)
            .filter(
              (q: any) =>
                q?.endpointName === "getTasks" && q?.status === "fulfilled"
            )
            .map((q: any) => q?.data),
        ];
        let prev: BacklogItem | undefined;
        for (const arr of tryCaches) {
          if (Array.isArray(arr)) {
            prev = arr.find((t) => t.id === arg.id);
            if (prev) break;
          }
        }
        try {
          await queryFulfilled;
          if (prev) dispatch(pushUndo({ kind: "tasks/add", task: prev }));
        } catch {}
      },
    }),
    upsertTaskLoad: b.mutation<
      BacklogItem,
      { taskId: string; sprintId: string; days: number }
    >({
      query: (body) => ({ url: "/taskload", method: "POST", body }),
      invalidatesTags: ["Task", "Capacity"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const state = getState() as RootState;
        const tasks =
          api.endpoints.getTasks.select(undefined)(state)?.data || [];
        const prevTask = tasks.find((t) => t.id === arg.taskId);
        const prev = prevTask?.loads?.[arg.sprintId] ?? 0;
        try {
          await queryFulfilled;
          dispatch(
            pushUndo({
              kind: "taskload/set",
              taskId: arg.taskId,
              sprintId: arg.sprintId,
              days: prev,
            })
          );
        } catch {}
      },
    }),
    upsertTaskAllocation: b.mutation<
      BacklogItem,
      { taskId: string; participantId: string; sprintId: string; days: number }
    >({
      query: (body) => ({ url: "/taskallocation", method: "POST", body }),
      invalidatesTags: ["Task", "Capacity"],
      async onQueryStarted(arg, { dispatch, getState, queryFulfilled }) {
        const state = getState() as RootState;
        const tasks =
          api.endpoints.getTasks.select(undefined)(state)?.data || [];
        const prevTask = tasks.find((t) => t.id === arg.taskId);
        const prev =
          prevTask?.allocations?.[arg.participantId]?.[arg.sprintId] ?? 0;
        try {
          await queryFulfilled;
          dispatch(
            pushUndo({
              kind: "taskallocation/set",
              taskId: arg.taskId,
              participantId: arg.participantId,
              sprintId: arg.sprintId,
              days: Number(prev) || 0,
            })
          );
        } catch {}
      },
    }),
    duplicateTask: b.mutation<BacklogItem, { id: string }>({
      query: (body) => ({ url: "/tasks/duplicate", method: "POST", body }),
      invalidatesTags: ["Task", "Capacity"],
      async onQueryStarted(arg, { dispatch, queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          dispatch(pushUndo({ kind: "tasks/delete", id: data.id }));
        } catch {}
      },
    }),
  }),
});

export const {
  useGetQuartersQuery,
  useAddQuarterMutation,
  useUpdateQuarterMutation,
  useDeleteQuarterMutation,

  useGetSprintsQuery,
  useAddSprintMutation,
  useUpdateSprintMutation,
  useDeleteSprintMutation,

  useGetParticipantsQuery,
  useAddParticipantMutation,
  useUpdateParticipantMutation,
  useDeleteParticipantMutation,
  useReorderParticipantsMutation,

  useGetRunVacationQuery,
  useUpsertRunVacationMutation,
  useBulkRunVacationMutation,
  useGetCapacityQuery,

  useGetTasksQuery,
  useAddTaskMutation,
  useUpdateTaskMutation,
  useDeleteTaskMutation,
  useUpsertTaskLoadMutation,
  useUpsertTaskAllocationMutation,
  useDuplicateTaskMutation,
} = api;
